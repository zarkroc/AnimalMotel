﻿namespace AnimalMotel
{
    /// <summary>
    /// Author: Tomas Perers, ai2891
    /// Date : 2019-02-06
    /// Updated a bit for the second attempt at the course.
    /// Project Animal motel v1
    /// </summary>
    public enum Category
    { 
        Bird,
        Mammal
    }
}
